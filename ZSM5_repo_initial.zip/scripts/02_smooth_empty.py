from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROC = ROOT / "data" / "processed"
FIG = ROOT / "figures"
PROC.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

arr = np.genfromtxt(RAW / "ZSM5140_empty.dat", delimiter=",", comments="#")
arr = arr[~np.isnan(arr).any(axis=1)]
x, y, e = arr[:,0], arr[:,1], arr[:,2]

def centered_average(y, n):
    out = np.empty_like(y, dtype=float)
    left = (n - 1) // 2
    right = n // 2
    for i in range(len(y)):
        lo = max(0, i-left)
        hi = min(len(y), i+right+1)
        out[i] = np.mean(y[lo:hi])
    return out

smooth = {n: centered_average(y, n) for n in [5,6,7,8]}

# Current agreed rule:
# 5 points to 500 cm^-1, then a linear increase to 8 points by 4500 cm^-1.
n_eff = np.where(
    x <= 500.0,
    5.0,
    np.where(x >= 4500.0, 8.0, 5.0 + 3.0*(x-500.0)/4000.0)
)

y_smooth = np.empty_like(y)
for i, ne in enumerate(n_eff):
    if ne <= 5:
        y_smooth[i] = smooth[5][i]
    elif ne >= 8:
        y_smooth[i] = smooth[8][i]
    else:
        lo = int(np.floor(ne))
        hi = int(np.ceil(ne))
        w = ne - lo
        y_smooth[i] = (1-w)*smooth[lo][i] + w*smooth[hi][i]

np.savetxt(
    PROC / "ZSM5140_empty_smoothed_5to8.dat",
    np.column_stack([x, y, e, y_smooth, n_eff]),
    delimiter=",",
    header="X_cm-1,raw_Y,raw_E,smoothed_Y,effective_window_points",
    comments=""
)

m = (x >= 20) & (x <= 4500)
fig, ax = plt.subplots(figsize=(12,6.5))
ax.plot(x[m], y[m], lw=0.75, alpha=0.4, label="Raw empty ZSM-5")
ax.plot(x[m], y_smooth[m], lw=1.35, label="5→8 point moving average")
ax.set_xlim(20,4500)
ax.set_xlabel(r"Wavenumber / cm$^{-1}$")
ax.set_ylabel("TOSCA intensity")
ax.set_title("Empty ZSM-5 smoothing used for planned subtraction")
ax.grid(alpha=0.15)
ax.legend()
fig.tight_layout()
fig.savefig(FIG / "02_empty_smoothing_5to8.png", dpi=200)
fig.savefig(FIG / "02_empty_smoothing_5to8.svg")
