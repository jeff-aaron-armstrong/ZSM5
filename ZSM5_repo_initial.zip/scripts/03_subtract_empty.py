"""
Planned next step.

Subtract the agreed smoothed empty-ZSM-5 spectrum from each loaded-zeolite
spectrum (MeOH 2/4/8 nominal wt%, 1-propanol 2/8 nominal wt%).

Do NOT subtract the empty zeolite from the pure methanol reference because it
was measured in a different can and contains no zeolite.

This script is intentionally left unexecuted until the subtraction/scaling
convention is agreed.
"""
