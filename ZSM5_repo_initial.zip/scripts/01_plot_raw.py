from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

files = [
    ("methanol.dat", "Methanol reference"),
    ("ZSM5140_empty.dat", "ZSM-5(140) empty"),
    ("ZSM5140_m2pc.dat", "ZSM-5(140) + MeOH nominal 2%"),
    ("ZSM5140_m4pc.dat", "ZSM-5(140) + MeOH nominal 4%"),
    ("ZSM5140_m8pc.dat", "ZSM-5(140) + MeOH nominal 8%"),
    ("ZSM5140_p2pc.dat", "ZSM-5(140) + 1-propanol nominal 2%"),
    ("ZSM5140_p8pc.dat", "ZSM-5(140) + 1-propanol nominal 8%"),
]

fig, ax = plt.subplots(figsize=(12, 7))
for fname, label in files:
    a = np.genfromtxt(RAW / fname, delimiter=",", comments="#")
    a = a[~np.isnan(a).any(axis=1)]
    m = (a[:,0] >= 20) & (a[:,0] <= 4500)
    ax.plot(a[m,0], a[m,1], lw=1.0, label=label)

ax.set_xlim(20, 4500)
ax.set_xlabel(r"Wavenumber / cm$^{-1}$")
ax.set_ylabel("Raw TOSCA intensity")
ax.set_title("Raw TOSCA spectra — no normalization or subtraction")
ax.legend(fontsize=8)
ax.grid(alpha=0.15)
fig.tight_layout()
fig.savefig(FIG / "01_raw_spectra_overlay.png", dpi=200)
fig.savefig(FIG / "01_raw_spectra_overlay.svg")
