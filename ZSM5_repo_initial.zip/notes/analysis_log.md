# Analysis log

## 25 September 2026 — repository initialized

### Experimental files
TOSCA spectra for highly siliceous ZSM-5 (nominal Si/Al ≈ 140) loaded with
methanol and 1-propanol.

The loading values encoded in filenames are **nominal dosing targets only**.
The actual dosed wt% may differ and should not yet be treated as quantitative.

### Raw data reading
Each `.dat` file has three columns:
1. X — wavenumber / energy-transfer axis
2. Y — TOSCA intensity
3. E — uncertainty

Raw spectra are retained unchanged in `data/raw/`.

### Current processing decision: empty-zeolite smoothing
The empty ZSM-5 spectrum will be used as the background subtraction for all
loaded-zeolite runs, but not for the pure methanol reference.

Current agreed smoothing:
- centered 5-point moving average up to 500 cm⁻¹;
- effective window then increases linearly;
- reaches 8 points at 4500 cm⁻¹.

This preserves sharp low-frequency framework structure while averaging more
strongly at high wavenumber, where the TOSCA grid is coarser/noisier.

### Not yet done
- no empty-zeolite subtraction has been applied;
- no intensity normalization/scaling has been applied;
- nominal wt% values have not been corrected;
- no spectral assignment is being claimed at this stage.
