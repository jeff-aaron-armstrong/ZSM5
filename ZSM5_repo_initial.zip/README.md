# ZSM5 — TOSCA methanol / 1-propanol experiment

Reproducible analysis of TOSCA spectra from methanol and 1-propanol dosed into
highly siliceous ZSM-5 (nominal Si/Al ≈ 140).

> **Important:** dosing percentages in filenames are nominal targets. The actual
> dosed wt% may differ and will be revisited from the experimental mass records.

## Data

`data/raw/` contains the original spectra exactly as supplied:

- `ZSM5140_empty.dat`
- `ZSM5140_m2pc.dat`
- `ZSM5140_m4pc.dat`
- `ZSM5140_m8pc.dat`
- `ZSM5140_p2pc.dat`
- `ZSM5140_p8pc.dat`
- `methanol.dat`

The pure methanol run was measured in a different can and does not contain
zeolite, so the empty-ZSM-5 spectrum must **not** be subtracted from it.

## Current workflow

1. Plot raw spectra (`scripts/01_plot_raw.py`).
2. Smooth the empty-ZSM-5 spectrum (`scripts/02_smooth_empty.py`).
3. Subtract the agreed empty spectrum from loaded zeolite runs — **next step,
   not yet performed**.
4. Reassess actual loading from mass/dosing records.
5. Compare experiment against classical and MLIP simulations.

## Current empty-zeolite smoothing

The agreed working smoother is a centered moving average that uses:

- 5 points up to 500 cm⁻¹;
- a gradual linear increase above 500 cm⁻¹;
- 8 points by 4500 cm⁻¹.

This is stored in:
`data/processed/ZSM5140_empty_smoothed_5to8.dat`.

## Figures

- `figures/01_raw_spectra_overlay.*`
- `figures/02_empty_smoothing_5to8.*`

## Reproducibility

```bash
pip install -r requirements.txt
python scripts/01_plot_raw.py
python scripts/02_smooth_empty.py
```

Detailed analysis decisions are recorded in `notes/analysis_log.md`.
